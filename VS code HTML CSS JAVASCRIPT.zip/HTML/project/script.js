function store(){
    window.localStorage.setItem("comments",document.getElementById("comments").value);
    window.localStorage.setItem("gender",document.getElementById("gender").value);
    window.location.href = "contact.html";
  }
  
  function validate(){
              var comment = document.getElementById("comments").value;
              var gender = document.getElementById("gender").value;
              var len = comment.length;
              if (len > 100)
              {
                  alert("Reduce the length of the comment less than 100 characters");
              }
              else if (gender == "Select Gender")
              {
                  alert("Please Select a gender");
              }
              else {
                  store();
              }
          }