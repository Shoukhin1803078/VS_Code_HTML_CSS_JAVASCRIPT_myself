function getValue(){
    var x=document.querySelector(".name").value;
    alert(x);
  }


