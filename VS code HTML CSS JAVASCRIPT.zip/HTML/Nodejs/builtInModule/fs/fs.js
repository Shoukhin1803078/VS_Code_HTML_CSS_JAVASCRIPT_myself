var x=require("fs");
// console.log(x);
x.appendFile("demo1.txt","name is shoukhin",function(err){
if(err){
    console.log("error found");
}
else{
    console.log("file write successfully");
}
});
