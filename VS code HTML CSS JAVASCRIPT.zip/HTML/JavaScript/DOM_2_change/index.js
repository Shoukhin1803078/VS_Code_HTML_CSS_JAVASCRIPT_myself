var x=document.querySelector("select.dept")
//console.log(x);
x.addEventListener("change",kaj);
function kaj(e)
{
    alert("apni akti option select koresen ");
    var y=e.target.value;
    //document.write(y);
    alert("value ti hosse = "+y);
//console.log(e.target.value)
}