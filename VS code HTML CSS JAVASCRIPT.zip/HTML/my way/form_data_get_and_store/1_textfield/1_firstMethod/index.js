
//ei method use korbo always
function getValue(){
    alert(document.querySelector(".name").value);
  }



        // ---------------first method (onclick use kore   tag er moddhe internally funtction diye )( for example button-1 er jonno) (function diye )-----------

    //   function get(){
    //     alert(document.querySelector(".name").value);
    //   }





      // -----------------second method (addEventListener diye) (general funtcion diye) ( for example button-2 er jonno) -----------



        //   var x=document.querySelector(".btn2");
        //   x.addEventListener("click",output);
        //   function output(e){
        // //   alert(e.target.value);//buttoner moddhe ki likha ase 
        //   alert(document.querySelector(".name").value); // input textfield e ki likha ase
        //   document.querySelector(".name").value=""; // ok dile input textfield ta faka hoye jabe 
        //   }


    // -----------------second method (anonimous funtcion diye) ( for example button-2 er jonno) (addEventListener diye)-----------



        //   var x=document.querySelector(".btn2");
        //   x.addEventListener("click",function(e){
        //     //   var y=document.querySelector(".name");
        //     //   alert(y.value);
        //     alert(document.querySelector(".name").value);
        //  });
      





    
    // -----------------second method (akline e sob) ( for example button-2 er jonno) (addEventListener diye)-----------



//    document.querySelector(".btn2").addEventListener("click",function(){
//     alert(document.querySelector(".name").value);
//    });





        //Ei method ti use korbo 
       // ----------------- third method (same first method)(Onclick property use kore + getElementById (eti faster onk karon direct id diye khujtesi)  and getElementByClass diye)(akline e sob )( for example button-3 er jonno) ----------------



      //  function output()
      //  {
      //      alert(document.querySelector(".name").value);
      //  }
   
 