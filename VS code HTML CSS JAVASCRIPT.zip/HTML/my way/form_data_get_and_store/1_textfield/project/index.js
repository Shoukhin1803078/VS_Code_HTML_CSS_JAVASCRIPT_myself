var x,y;
function get()
{
     x=document.querySelector(".name").value;
     y=document.querySelector(".age").value;
    alert("name: "+x+"   Age: "+y);

}
var z=require("fs");
z.appendFile("1_textfield_project.txt","welcome",function(err){
     console.log("successfully written on file");
});
