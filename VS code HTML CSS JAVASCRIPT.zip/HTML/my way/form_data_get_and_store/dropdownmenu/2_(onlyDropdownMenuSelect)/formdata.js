//----------first method-------


// const d=document.querySelector(".dept");
// console.log(d);
// d.addEventListener('change',myfunction);//normal function diye 
// function myfunction(e)
// {
//     console.log(e.target.value);

// }

//----------second method----------

// var d=document.querySelector(".dept");
// // console.log(d);
// d.addEventListener('click',function(e){ //anonimous funtion diye 
//      alert(e.target.value)
//     });


//----------third method(aksathe sob)----------

document.querySelector(".dept").addEventListener("change",function(e){
    alert(e.target.value);
});