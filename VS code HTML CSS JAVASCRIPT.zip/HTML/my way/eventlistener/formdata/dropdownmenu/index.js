var x=document.querySelector("#dept");
x.addEventListener('change',handle);
function handle(e){
    document.querySelector(".output").innerHTML=e.target.value;
    console.log(e.target.value);
}